//Pattern printing
/*
* * * * *
* * * * *
* * * * *
* * * * *
* * * * *
*/
#include<iostream>
using namespace std;
int main(){
	int row,col;
	
	for(row=1;row<=5;row++){
		for(col=1;col<=5;col++){
			cout<<"* ";//print star
		}
		cout<<endl;//next line
	}
}
