//number triangle reverse
/*
    *
   **
  ***
 ****
*****
*/
#include<iostream>
using namespace std;
int main(){
	int row,col;
	
	for(row=1;row<=5;row++){
		for(col=1;col<=5-row;col++){//space printing
			cout<<"  ";
		}
		for(col=1;col<=row;col++){//star printing
			cout<<" *";
		}
		cout<<endl;
	}
}
