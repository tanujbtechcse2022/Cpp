//Super Hard Patterns
/*
* * * * * * * * *
  * * * * * * *
    * * * * *
      * * *
        *
 */
 #include<iostream>
 using namespace std;
 int main(){
 	int n,row,col;
 	cout<<"Enter the number: ";
 	cin>>n;
 	
 	for(row=1;row<=n;row++){
 		for(col=1;col<=row-1;col++){
 			cout<<"  ";
 		}
 			for(col=1;col<=(2*n)-1-2*(row-1);col++){
 				cout<<" *";
			 }
		 cout<<endl;
	 }
 }
